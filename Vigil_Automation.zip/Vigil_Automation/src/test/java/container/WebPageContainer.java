package container;

import BasePage.StartDriver;
import Pages.overview_page;
import Pages.page;
import Pages.uptime_Check_page;
import org.openqa.selenium.WebDriver;

public class WebPageContainer {

    private WebDriver driver;

    public page page;
    public overview_page overviewPage;
    public uptime_Check_page uptimeCheckPage;

    public WebPageContainer() {
        driver = StartDriver.getDriver();
        initPages();
    }


    private void initPages() {
        page = new page(driver);
        overviewPage = new overview_page(driver);
        uptimeCheckPage = new uptime_Check_page(driver);


    }


}
