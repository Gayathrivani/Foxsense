package BasePage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class StartDriver {


    public static WebDriver driver;

    public static WebDriver getDriver(){
        String strBrowser = "chrome";
        if (driver == null) {
            System.out.println(strBrowser+ " Launch ---------------");
            driver = new ChromeDriver();
        }
        return driver;
        }


    }