package step_definition;

import container.WebPageContainer;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

import java.time.Duration;

import static BasePage.StartDriver.driver;
import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class login_steps {

    private WebPageContainer pageContainer;

    public static Response response;
    public int StatusCode;
    public String requestBody;
    public String token;

    public login_steps(WebPageContainer pageContainer){
        this.pageContainer = pageContainer;
    }
//    @AfterTest
//    public void tearDown() {
//        // Quit WebDriver {
//        if (driver != null) {
//            System.out.println("------------------- browser quit");
//            driver.quit();
//        }

//    }

    @Given("Launch the vigil url")
    public void launch_the_vigil_url() {
        pageContainer.page.visit();
    }

    @When("Login by using the valid credential")
    public void login_by_using_the_valid_credential() throws InterruptedException {
        Thread.sleep(3000);
        driver.findElement(By.xpath("//p[contains(text() ,'Email Address')]//following::input[1]")).sendKeys(new CharSequence[]{"ashik+hybrid@foxsense.io"});
        driver.findElement(By.xpath("//p[contains(text() ,'Email Address')]//following::input[2]")).sendKeys("Password1!");
        Thread.sleep(5000);
//        driver.findElement(By.xpath("//div[@Class= 'recaptcha-checkbox-spinner']")).click();
        driver.findElement(By.xpath("//p[text()='Login']")).click();

    }
    @Then("Verify the Home page")
    public void verify_the_home_page() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement toastMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='Toastify__toast-body']")));
        String messageText = toastMessage.getText();
        Assert.assertEquals("Logged in successfully", messageText);
        System.out.println("Toast message:    "+  messageText);
        Thread.sleep(5000);
        String title=  driver.getTitle();
        System.out.println("The user is " +title);



    }

    @When("Login by using the {string} and {string} credential")
    public void loginByUsingTheAndCredential(String UN, String PWD) throws InterruptedException {
        driver.findElement(By.xpath("//p[contains(text() ,'Email Address')]//following::input[1]")).sendKeys(UN);
        driver.findElement(By.xpath("//p[contains(text() ,'Email Address')]//following::input[2]")).sendKeys(PWD);
        Thread.sleep(10000);
        driver.findElement(By.xpath("//p[text()='Login']")).click();


    }

    @Then("Verify the error message")
    public void verifyTheErrorMessage() {
        if(driver.getTitle().equalsIgnoreCase("(99+) Home | Vigil")){
            System.out.println("Test Pass");
        } else {
            System.out.println("Test Failed");
        }

    }

    @Given("the user ready with URL and request body")
    public void theUserReadyWithURLAndRequestBody() {
        RestAssured.baseURI = "https://uat-api.vigilsandbox.com";
        requestBody =
                "{\n" +
                        "  \"email\": \"ashik+automation@foxsense.io\",\n" +
                        "  \"password\": \"Password1!\"\n" +
                        "}";

        System.out.println("req  : "+requestBody);
    }

    @When("the user hit the POST API for login")
    public void theUserHitThePOSTAPIForLogin() {
        response = given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .post("/api/v1/auth/login");
        System.out.println("---response : " + response.prettyPrint());


    }

    @Then("the user get the token from the response")
    public String theUserGetTheTokenFromTheResponse() {
        StatusCode = response.getStatusCode();
        assertEquals(StatusCode, 201, "Unexpected status code");
//         Validate specific details in the response body
         token = response.jsonPath().getString("data.accessToken");
        System.out.println("Status code after updating a post is -----"+StatusCode);
        System.out.println("Token =   "+ token + " --------" );
        return token;
    }


}