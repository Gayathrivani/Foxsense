package step_definition;

import io.cucumber.java.en.And;

public class sample {
    @And("User is on Google page")
    public void userIsOnGooglePage() {
    }
}
