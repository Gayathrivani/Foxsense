package step_definition;

import container.WebPageContainer;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import javax.swing.*;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static BasePage.StartDriver.driver;

public class add_uptime_check {

    private WebPageContainer pageContainer;

    public add_uptime_check(WebPageContainer pageContainer){
        this.pageContainer = pageContainer;
    }

    public WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));


    @Given("the user is on Uptime check page")
    public void theUserIsOnUptimeCheckPage() {
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Applications Down Recently']")));
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.uptimeCheck)).click();
//        pageContainer.uptimeCheckPage.uptimeCheck.click();
        System.out.println("Title----- "+ driver.getTitle());
    }

    @When("the user add the check")
    public void theUserAddTheCheck() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Date Range']")));
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.addCheckBtn)).click();
        System.out.println("Add check button is clicked");
        pageContainer.uptimeCheckPage.detailsPage.isDisplayed();
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.urlField)).sendKeys("https://www.google.com/");
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.applicationName)).sendKeys("test");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.nextBtn)).click();
        pageContainer.uptimeCheckPage.teammatesPage.isDisplayed();
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.skipBtn)).click();
        pageContainer.uptimeCheckPage.authenticationPage.isDisplayed();
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.skipBtn)).click();
        pageContainer.uptimeCheckPage.headerPage.isDisplayed();
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.headerField)).sendKeys("test");
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.valueField)).sendKeys("automation");
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.httpHeaderAddCheckBtn)).click();


    }

    @Then("verify the data should be added")
    public void verifyTheDataShouldBeAdded() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.toastMsg)).isDisplayed();
        String toastMsg=pageContainer.uptimeCheckPage.toastMsg.getText();
        System.out.println("Toast message  :   "+ toastMsg);
//        driver.navigate().refresh();
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        Thread.sleep(5000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Date Range']"))).isDisplayed();
//        driver.findElement(By.xpath("//*[text()='URL')]")).isDisplayed();
//        driver.findElement(By.xpath("//*[text()='https://www.google.com/')]")).isDisplayed();

    }

    @When("the user edit the check")
    public void theUserEditTheCheck() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.editBtn)).click();
        System.out.println("Edit button is clicked");
        pageContainer.uptimeCheckPage.detailsPage.isDisplayed();
//        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.applicationName)).clear();
//        pageContainer.uptimeCheckPage.applicationName.clear();
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.applicationName)).sendKeys("1");
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.nextBtn)).click();
        pageContainer.uptimeCheckPage.teammatesPage.isDisplayed();
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.skipBtn)).click();
        pageContainer.uptimeCheckPage.authenticationPage.isDisplayed();
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.skipBtn)).click();
        pageContainer.uptimeCheckPage.headerPage.isDisplayed();
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.headerField)).sendKeys("1");
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.valueField)).sendKeys("1");
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.httpHeaderAddCheckBtn)).click();


    }

    @Then("verify the data should be edited")
    public void verifyTheDataShouldBeEdited() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.toastMsg)).isDisplayed();
        String toastMsg=pageContainer.uptimeCheckPage.toastMsg.getText();
        System.out.println("Toast message  :   "+ toastMsg);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Date Range']")));
//        driver.findElement(By.xpath("//p[text()='test1')]")).isDisplayed();

    }


    @When("the user delete the check")
    public void theUserDeleteTheCheck() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
//        pageContainer.uptimeCheckPage.scroll();
//        wait.until(ExpectedConditions.invisibilityOf(pageContainer.uptimeCheckPage.toastMsg));
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.deleteBtn)).click();
        System.out.println("Delete button is clicked");
        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.uptimeCheckPage.deleteBtnOnPopup)).click();

    }

    @Then("verify the data should be deleted")
    public void verifyTheDataShouldBeDeleted() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOf(pageContainer.uptimeCheckPage.toastMsg)).isDisplayed();
        String toastMsg=pageContainer.uptimeCheckPage.toastMsg.getText();
        System.out.println("Toast message  :   "+ toastMsg);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Date Range']")));
//        wait.until(ExpectedConditions.invisibilityOfElementWithText(By.xpath("//p[text()='test1')]"),"test1"));


          }
}
