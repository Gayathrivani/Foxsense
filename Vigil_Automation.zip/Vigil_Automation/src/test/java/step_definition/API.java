package step_definition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import jdk.nashorn.internal.parser.Token;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class API {

    public static Response response;
    public int StatusCode;
    public String requestBody;
    public String token;

    @Given("open browser")
    public void openBrowser() {
        RestAssured.baseURI = "https://uat-api.vigilsandbox.com";
        requestBody =
                "{\n" +
                "  \"email\": \"ashik+automation@foxsense.io\",\n" +
                "  \"password\": \"Password1!\"\n" +
                "}";

        System.out.println("req  : "+requestBody);

    }

    @When("Hit vigil login API")
    public void hitVigilLoginAPI() {
        response = given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .post("/api/v1/auth/login");
        System.out.println("---response : " + response.prettyPrint());
    }

    @Then("Get token")
    public String getToken() {
        StatusCode = response.getStatusCode();
        assertEquals(StatusCode, 201, "Unexpected status code");
//         Validate specific details in the response body
         token = response.jsonPath().getString("data.accessToken");

        System.out.println("Status code after updating a post is -----"+StatusCode);
        System.out.println("Token =   "+ token  );
        return token;

    }
}
