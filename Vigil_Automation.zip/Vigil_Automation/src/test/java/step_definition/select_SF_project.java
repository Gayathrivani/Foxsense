package step_definition;

import container.WebPageContainer;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static BasePage.StartDriver.driver;

public class select_SF_project {
    private WebPageContainer pageContainer;

    public select_SF_project(WebPageContainer pageContainer){
        this.pageContainer = pageContainer;
    }

    public WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

    @Given("the user is authenticated")
    public void authenticateUser() {
        // Perform authentication and retrieve authToken
        pageContainer.overviewPage.visit();
          }

    @When("the user navigates to the test URL")
    public void navigateToTestURL() {
//        String testURL = "https://uat.vigilsandbox.com/redirect";
//        String URL=testURL+ "?token=" + authToken;
//        driver.get(URL);
//
//        driver.get(testURL);
////        System.out.println("------Test-------"+driver.getCurrentUrl());
//        System.out.println("-------"+URL);
//        pageContainer.page.visit();
    }


    @Given("the user is on overview page")
    public void theUserIsOnOverviewPage() throws InterruptedException {
        pageContainer.overviewPage.visit();
        Thread.sleep(10000);

//        driver.findElement(By.xpath("//p[text()='Overview']")).isDisplayed();
        System.out.println("Title-------" + driver.getTitle());
        pageContainer.overviewPage.Overview.isDisplayed();

    }

    @When("the FS project is selected")
    public void theFSProjectIsSelected() {
        wait.until(ExpectedConditions.visibilityOf(pageContainer.overviewPage.FS));

        pageContainer.overviewPage.FS.isDisplayed();
        System.out.println("Project name :     "+ pageContainer.overviewPage.FS.getText());
    }

    @Then("verify the overview page elements")
    public void verifyTheOverviewPageElements() {

        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
//        String dropdown=driver.findElement(By.cssSelector("#project-dashboard-dropdown div")).getText();
        String[] idsToCheck = {
                "healthstatus-overview",
                "job-monitoring-overview",
                "exception-overview",
//                "api-monitoring-overview",
                "Overview",
                "Errors",
                "Uptime Checks",
                "Escalations",
//                "APEX Jobs",
//                "API Monitoring",
                "Settings"
        };

            for (String Id : idsToCheck) {
                List<WebElement> component = driver.findElements(By.id(Id));
                if (!component.isEmpty()) {
                    System.out.println("Element with ID '" + Id + "' is present on the page.");
                    // You can perform further actions here if needed
                } else {
                    System.out.println("Element with ID '" + Id + "' is NOT present on the page.");
                }
            }



    }

    @When("the user select the SF on the project")
    public void theUserSelectTheSFOnTheProject() throws InterruptedException {
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Applications Down Recently']")));

        wait.until(ExpectedConditions.elementToBeClickable(pageContainer.overviewPage.prjdropdown)).click();
        System.out.println("Dropdown element is clicked");

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'SF')]"))).click();
//        isSFProjectPresent = true;
        System.out.println("Clicked on SF element");
        Thread.sleep(3000);



    }

    @And("verify the API monitoring is visible")
    public void verifyTheAPIMonitoringIsVisible() {
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
//        String dropdown=driver.findElement(By.cssSelector("#project-dashboard-dropdown div")).getText();
        String[] idsToCheck = {
                "api-monitoring-overview",
//                "APEX Jobs",
                "API Monitoring"
        };
        if(pageContainer.overviewPage.FS.isDisplayed()){

            for (String Id : idsToCheck) {
                List<WebElement> component = driver.findElements(By.id(Id));
                if (!component.isEmpty()) {
                    System.out.println("Element with ID '" + Id + "' is present on the page.");
                    // You can perform further actions here if needed
                } else {
                    System.out.println("Element with ID '" + Id + "' is NOT present on the page.");
                }
            }
        }

    }

    @And("verify the API monitoring is not visible")
    public void verifyTheAPIMonitoringIsNotVisible() {
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
//        String dropdown=driver.findElement(By.cssSelector("#project-dashboard-dropdown div")).getText();
        String[] idsToCheck = {
                "api-monitoring-overview",
//                "APEX Jobs",
                "API Monitoring"
        };
        wait.until(ExpectedConditions.visibilityOf(pageContainer.overviewPage.SF)).isDisplayed();
        if (pageContainer.overviewPage.SF.isDisplayed()) {
            for (String Id : idsToCheck) {
                List<WebElement> component = driver.findElements(By.id(Id));
                if (component.isEmpty()) {
                    System.out.println("Element with ID '" + Id + "' is NOT present on the page.");
                    // You can perform further actions here if needed
                } else {
                    System.out.println("Element with ID '" + Id + "' is  present on the page.");
                }
            }

        }

    }
}
