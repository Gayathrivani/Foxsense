package step_definition;

import container.WebPageContainer;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import org.openqa.selenium.By;
import static BasePage.StartDriver.driver;

public class MyStepdefs {


    private WebPageContainer pageContainer;

    public MyStepdefs(WebPageContainer pageContainer){
        this.pageContainer = pageContainer;
    }


    @Given("User is on Google homepage")
    public void userIsOnGoogleHomepage() throws InterruptedException {
        pageContainer.page.visit();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//p[contains(text() ,'Email Address')]//following::input[1]")).sendKeys(new CharSequence[]{"ashik+hybrid@foxsense.io"});
        driver.findElement(By.xpath("//p[contains(text() ,'Email Address')]//following::input[2]")).sendKeys("Password1!");


    }

    @When("User enters {string} in the search bar")
    public void userEntersInTheSearchBar(String arg0) {

    }

    @And("User clicks on the search button")
    public void userClicksOnTheSearchButton() {
    }

    @Then("Search results for {string} are displayed")
    public void searchResultsForAreDisplayed(String arg0) {
    }

}
