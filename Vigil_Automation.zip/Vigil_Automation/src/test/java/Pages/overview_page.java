package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class overview_page {

    static WebDriver driver;

    private static String authToken;

    public overview_page(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void visit() {
        driver.manage().window().maximize();
//        driver.navigate().to("https://uat.vigilsandbox.com/signIn");

        String testURL = "https://uat.vigilsandbox.com/redirect";
        authToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFzaGlrK2F1dG9tYXRpb25AZm94c2Vuc2UuaW8iLCJ1c2VyTmFtZSI6ImYwZDI3ZWQ0M2FmOTRlMGUyYWQ5YjAzNWIxYjA4YzhhIiwic3ViIjoiNTE5MDBiZGUtNDRjMi00ODZmLTk3MDgtYjQ2ZTk0MGIxNmMyIiwiaWF0IjoxNzE0NDUzNzc4LCJleHAiOjE3MTQ1NDAxNzh9._fF3OlbyIIUKzfHOlRk13RtEL0O1wRbrh3h3V4RM2Gw";
//        String authToken= theUserGetTheTokenFromTheResponse();
        driver.get(testURL + "?token=" + authToken);
        driver.get(testURL);
    }

    @FindBy(how = How.XPATH, xpath = "//p[text()='Overview']")
    public static WebElement Overview;

    @FindBy(how = How.XPATH, xpath = "//p[text()='FS']")
    public static WebElement FS;

    @FindBy(how = How.XPATH, xpath = "//p[text()='SF']")
    public static WebElement SF;

    @FindBy(how = How.ID, id = "project-dashboard-dropdown")
    public static WebElement prjdropdown;

}
