package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class page {


    static WebDriver driver;



    public page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void visit() {
        driver.manage().window().maximize();
        driver.navigate().to("https://uat.vigilsandbox.com/");
    }


    public static void screenshot() {
//        TakesScreenshot ts = (TakesScreenshot) driver;
//        // Capture screenshot as output type FILE
//        File file = ts.getScreenshotAs(OutputType.FILE);
//
//        try {
//            //save the screenshot taken in destination path
//            FileUtils.copyFile(file, new File("./ScreenShot_Folder/ecommerce_plaground.png"));
//            // Print the title after screenshot capture
//            String title = driver.getTitle();
//            System.out.println("Captured Screenshot for: " + title);
//        } catch (IOException e) {
//            // Catch any unexpected errors
//            e.printStackTrace();
//        }
    }
}
