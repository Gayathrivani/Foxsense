package Pages;

import io.cucumber.java.an.E;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import javax.swing.*;

public class uptime_Check_page extends overview_page{


    public uptime_Check_page(WebDriver driver) {
        super(driver);
    }

    @FindBy(how = How.ID, id="Uptime Checks")
    public static WebElement uptimeCheck;

    @FindBy(how = How.ID, id = "Add Health Check")
    public static WebElement addCheckBtn;

    @FindBy(how = How.XPATH, xpath = "//div[text()='details']")
    public static WebElement detailsPage;

    @FindBy(how = How.NAME, name = "url")
    public static WebElement urlField;

    @FindBy(how = How.NAME, name = "checkName")
    public static WebElement applicationName;

//    @FindBy(how = How.ID,id = "Primary info Next")
    @FindBy(how = How.XPATH, xpath = "//div[@id='Primary info Next']//descendant::button")
    public static WebElement nextBtn;

    @FindBy(how = How.XPATH, xpath = "//div[text()='teammates']")
    public static WebElement teammatesPage;

    @FindBy(how = How.ID, id = "skip-step-component")
    public static WebElement skipBtn;

    @FindBy(how = How.XPATH, xpath = "//div[text()='authentication credentials']")
    public static WebElement authenticationPage;

    @FindBy(how = How.XPATH, xpath = "//div[text()='header and value']")
    public static WebElement headerPage;

    @FindBy(how = How.NAME, name = "value")
    public static WebElement headerField;

    @FindBy(how = How.NAME, name = "key")
    public static WebElement valueField;

    @FindBy(how = How.ID, id = "Http Headers Add Check")
    public static WebElement httpHeaderAddCheckBtn;


    @FindBy(how = How.XPATH, xpath = "//div[@class='Toastify__toast-body']")
    public static WebElement toastMsg;

    @FindBy(how = How.ID,id = "test-ahc-edit")
    public static WebElement editBtn;

    @FindBy(how = How.ID,id = "test1-ahc-delete")
    public static WebElement deleteBtn;

    @FindBy(how = How.ID, id = "delete")
    public static WebElement deleteBtnOnPopup;

    public static void scroll(){
        Actions actions = new Actions(driver);
        actions.moveToElement((WebElement) driver.findElement(By.id("test1-ahc-delete"))).click().sendKeys(Keys.PAGE_DOWN).build().perform();

    }



}
